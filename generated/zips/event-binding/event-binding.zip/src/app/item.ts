export class Item {
  name: '';
}

