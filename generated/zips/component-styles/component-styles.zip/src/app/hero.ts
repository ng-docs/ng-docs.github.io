export class Hero {
  active = false;

  constructor(public name: string,
              public team: string[]) {
  }
}
