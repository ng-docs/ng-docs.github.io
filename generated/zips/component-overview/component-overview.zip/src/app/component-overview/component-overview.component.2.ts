import { Component } from '@angular/core';

@Component({
  selector: 'app-component-overview',
  template: `
    <h1>Hello World!</h1>
    <p>This template definition spans multiple lines.</p>
  `
})
export class ComponentOverviewComponent {

}

